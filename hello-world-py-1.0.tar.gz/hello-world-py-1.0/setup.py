#!/usr/bin/env python

from distutils.core import setup

setup(name='hello-world-py',
  version='1.0',
  description='A basic hello world package',
  author='zurfyx',
  url='https://github.com/zurfyx',
  packages=['hello'],
 )

import Hello

def main():
    # APP CODE
    app = Hello.Hello()
    print app.hello_world()

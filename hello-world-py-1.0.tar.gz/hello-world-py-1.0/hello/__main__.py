#!/usr/bin/env python

# $ python hello/__main__.py (2.6+)
# $ python -m hello          (2.7+)

import sys

import hello

if __name__ == '__main__':
    hello.main()

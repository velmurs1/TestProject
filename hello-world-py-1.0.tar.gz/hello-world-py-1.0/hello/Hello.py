class Hello(object):

    def hello_world(self):
        return 'Hello World!'
